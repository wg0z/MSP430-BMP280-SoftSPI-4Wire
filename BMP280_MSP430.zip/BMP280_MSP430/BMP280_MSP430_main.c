//
// BMP280_MSP430_main.c
//
//  Software/bit-bang SPI interface to BMP280 : demo for low-end MSP430 devices
//  developed using an MSP430G2211 on an MSP-EXP430G2 launchpad  7/2017
//
//  J J Hastings WG0Z
//
//  port/usage guide:
//     1) the config header file has 4 blocks of macros/symbol defines
//        each block is 4 lines
//        users should set the first 3 defines of each block as required to match
//        the exact wiring interconnections used
//     2) the BMP280 is capable of 20 bit resolution for temp and pressure
//        but this demo uses only 16-bit results

#include <msp430.h>
#include "BMP280_named_numbers.h"
#include "BMP280_prototypes.h"


static unsigned Temp, Pressure, Id;


void softDelay( void )
{
    volatile unsigned ix = 500;
    do
    {
        ix--;
    }
    while ( ix );
}


void main(void)
{



    WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
	
    BMP280_if_init();

    Id = BMP280_readID(); // Id _should_ be 0x58

    for(;;)
    {
        BMP280_force_conversions();

        // always delay a few milliseconds
        softDelay();

        // now wait until conversion has definitely completed,
        // which will be when the 'measuring' bit (bit 3) in the
        // status register is false
        do {} while (BMP280_readStatus() & MEASURING_BIT_MASK);


        // get conversion results
        Temp = BMP280_readTemperature();
        Pressure = BMP280_readPressure();
    } // end for(ever)

} // end main()
